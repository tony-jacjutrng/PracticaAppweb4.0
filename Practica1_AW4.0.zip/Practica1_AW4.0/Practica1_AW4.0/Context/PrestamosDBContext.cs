﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Practica1_AW4._0.Models;

namespace Practica1_AW4._0.Context
{
    public class PrestamosDBContext: DbContext
    {
        public PrestamosDBContext(DbContextOptions<PrestamosDBContext>options):base(options)
        {
        }
        public DbSet<Libro> Libros { get; set; }
        public DbSet<Empleado> Empleados { get; set; }
        public DbSet<Usuario> Usuarios { get; set; }
        public DbSet<Prestamo>Prestamos { get; set; }
    }
}
