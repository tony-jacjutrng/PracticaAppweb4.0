﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Practica1_AW4._0.Models
{
    public class Libro
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ISBN { get; set; }

        public string Titulo { get; set; }

        public int Nopaginas { get; set; }

        public int Edicion { get; set; }

        public string Editorial { get; set; }

        public string Clasificado { get; set; }

        public string F_publicacion { get; set; }

        public string Nombre_autor { get; set; }

        public string Apellidos { get; set; }

        public string Direccion { get; set; }

        public string Telefono { get; set; }

        public string Nacionalidad { get; set; }

        public string Idioma { get; set; }

        public string Pasillo { get; set; }

        public string Estante { get; set; }

    }
}
