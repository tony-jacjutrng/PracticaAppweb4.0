﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Practica1_AW4._0.Models
{
    public class Prestamo
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]

        public int Id { get; set; }

        [ForeignKey("Libro")]

        public int ISBN { get; set; }

        public int Cantidad { get; set; }

        [ForeignKey("Usuario")]

        public int Codigo_us { get; set; }

        [ForeignKey("Empleado")]

        public int Id_empleado { get; set; }

        public DateTime Fecha_limite { get; set; }

        public DateTime Fecha_entrega { get; set; }

        public DateTime Hora_entrega { get; set; }

    }
}
